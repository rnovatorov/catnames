# CSRF protection
WTF_CSRF_ENABLED = True
SECRET_KEY = "my_super_secret_key"


# VK API info
VK_APP_ID = "5947995"
VK_APP_SECRET = "JHuA148yGWtHAvRHkWUb"
VK_SERVICE_TOKEN = "a6ce7dcca6ce7dcca696b458e7a694bf97aa6cea6ce7dccfe19b95748948815584e1af6"
VK_API_VERSION = "5.63"


# Just for development
VK_REDIRECT_URI = "http://ovz1.novrr.6pqj1.vps.myjino.ru/localhost_redirect/"


# VK test user credentials
VK_TEST_USER_PHONE = "89618055703"
VK_TEST_USER_PASSWORD = "427Wpt0MfZJIaqVDipXB"
